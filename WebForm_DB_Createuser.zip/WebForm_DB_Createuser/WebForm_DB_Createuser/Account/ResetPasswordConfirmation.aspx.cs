﻿using System.Web.UI;

namespace WebForm_DB_Createuser.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}